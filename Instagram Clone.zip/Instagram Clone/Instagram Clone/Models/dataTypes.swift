//
//  dataTypes.swift
//  Instagram Clone
//
//  Created by Kavsoft on 23/10/19.
//  Copyright © 2019 Kavsoft. All rights reserved.
//

import Foundation
import SwiftUI


struct datatype1 : Identifiable {
    
    var id : String
    var name : String
    var image : String
    var comments : String
    var likes : String
}


struct datatype : Identifiable {
    
    var id : String
    var name : String
    var image : String
}
