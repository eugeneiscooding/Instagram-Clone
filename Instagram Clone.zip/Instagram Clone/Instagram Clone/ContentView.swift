//
//  ContentView.swift
//  Instagram Clone
//
//  Created by Kavsoft on 22/10/19.
//  Copyright © 2019 Kavsoft. All rights reserved.
//

// import your google info.plist file to avoid errors

import SwiftUI
import Firebase
import SDWebImageSwiftUI


struct ContentView: View {
    var body: some View {
        
        TabView{
            
            NavigationView{
                
                Home()
                    .navigationBarTitle("Instagram")
                    .navigationBarItems(leading: Button(action: {
                        
                    }, label: {
                        
                        Image("cam").resizable().frame(width: 30, height: 30)
                        
                    })
                    .foregroundColor(Color("darkAndWhite"))
                    , trailing:
                
                        HStack{
                            
                            Button(action: {
                                
                            }) {
                                
                                Image("IGTV").resizable().frame(width: 30, height: 30)
                                
                            }.foregroundColor(Color("darkAndWhite"))
                            
                            Button(action: {
                                
                            }) {
                                
                                Image("send").resizable().frame(width: 30, height: 30)
                            }
                            .foregroundColor(Color("darkAndWhite"))
                        }
                
                )
                
                
            }.tabItem {
                
                Image("home")
            }
            
            Text("Find").tabItem {
                
                Image("find")
            }
            
            Text("Upload").tabItem {
                
                Image("plus")
            }
            
            Text("Likes").tabItem {
                
                Image("heart")
            }
            
            Text("Profile").tabItem {
                
                Image("people")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// oops i forget to add sdwebimage dependency.....
// now u can see status is automatically updated...
// if status is removed .....
// you can see that the status is automatically updated when its added or removed......
// now posts .....
// you can also see that the posts updates automatically when there is changes.....

// now like updates....

// you can see that both status and updates working fine and automatically updates when there is change in DB......

// time to clean the code....

