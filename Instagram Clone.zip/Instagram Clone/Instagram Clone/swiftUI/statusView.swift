//
//  statusView.swift
//  Instagram Clone
//
//  Created by Kavsoft on 23/10/19.
//  Copyright © 2019 Kavsoft. All rights reserved.
//

import SwiftUI
import SDWebImageSwiftUI

struct statusView : View {
    
    var url = ""
    var name = ""
    
    var body : some View{
        
        ZStack{
            
            AnimatedImage(url: URL(string: url)).resizable()
            
            VStack{
                
                HStack{
                    
                    Text(name).font(.headline).fontWeight(.heavy).padding()
                    Spacer()
                }
                Spacer()
            }
        }
        
    }
}
